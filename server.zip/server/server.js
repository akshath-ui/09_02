'use strict';

/**
 * Smart Harbour API – server.js
 * ─────────────────────────────
 * A lightweight Express.js backend for the Smart Fishing Harbour frontend.
 *
 * Start:        node server.js          (or npm start)
 * Development:  npx nodemon server.js   (or npm run dev)
 *
 * All data is kept in-memory; the store is seeded from data/store.js on boot.
 * To persist data across restarts, swap the store for a real database.
 */

require('dotenv').config();

const express    = require('express');
const cors       = require('cors');
const morgan     = require('morgan');
const path       = require('path');

const pricesRouter        = require('./routes/prices');
const storageRouter       = require('./routes/storage');
const announcementsRouter = require('./routes/announcements');
const { notFound, errorHandler } = require('./middleware');

// ── App ───────────────────────────────────────────────────────────────────────
const app  = express();
const PORT = process.env.PORT || 3001;

// ── Global Middleware ─────────────────────────────────────────────────────────
app.use(cors({
  origin: process.env.CORS_ORIGIN || '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'x-api-key'],
}));

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// HTTP request logger (skip in test env)
if (process.env.NODE_ENV !== 'test') {
  app.use(morgan('dev'));
}

// ── Serve the frontend static files ──────────────────────────────────────────
// The index.html lives one directory above server/
app.use(express.static(path.join(__dirname, '..')));

// ── Health Check ──────────────────────────────────────────────────────────────
app.get('/api/health', (_req, res) => {
  res.json({
    success: true,
    service: 'Smart Harbour API',
    version: '1.0.0',
    env: process.env.NODE_ENV || 'development',
    uptime: Math.round(process.uptime()),
    timestamp: new Date().toISOString(),
  });
});

// ── API Routes ────────────────────────────────────────────────────────────────
app.use('/api/prices',        pricesRouter);
app.use('/api/storage',       storageRouter);
app.use('/api/announcements', announcementsRouter);

// ── API root – list all endpoints ─────────────────────────────────────────────
app.get('/api', (_req, res) => {
  res.json({
    success: true,
    message: 'Smart Harbour API',
    version: '1.0.0',
    endpoints: {
      health: 'GET  /api/health',
      prices: {
        list:    'GET  /api/prices',
        get:     'GET  /api/prices/:id',
        update:  'PUT  /api/prices/:id          🔑',
        history: 'GET  /api/prices/:id/history',
      },
      storage: {
        list:    'GET  /api/storage',
        summary: 'GET  /api/storage/summary',
        byHarbour: 'GET  /api/storage/harbour/:harbour',
        get:     'GET  /api/storage/:id',
        update:  'PUT  /api/storage/:id         🔑',
      },
      announcements: {
        list:      'GET    /api/announcements',
        byHarbour: 'GET    /api/announcements/harbour/:harbour',
        get:       'GET    /api/announcements/:id',
        create:    'POST   /api/announcements   🔑',
        update:    'PUT    /api/announcements/:id 🔑',
        delete:    'DELETE /api/announcements/:id 🔑',
      },
    },
    auth: '🔑 = requires x-api-key header (or ?apiKey= query param)',
  });
});

// ── 404 & Error Handlers ──────────────────────────────────────────────────────
app.use(notFound);
app.use(errorHandler);

// ── Start ─────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🐟  Smart Harbour API running`);
  console.log(`   Local:    http://localhost:${PORT}`);
  console.log(`   Frontend: http://localhost:${PORT}/`);
  console.log(`   API root: http://localhost:${PORT}/api`);
  console.log(`   Env:      ${process.env.NODE_ENV || 'development'}\n`);
});

module.exports = app; // exported for testing
