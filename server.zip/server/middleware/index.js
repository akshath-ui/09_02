'use strict';

/**
 * requireApiKey — guards every mutating route (POST / PUT / DELETE)
 *
 * Clients must send the key either as:
 *   • HTTP header  x-api-key: <key>
 *   • Query param  ?apiKey=<key>
 */
function requireApiKey(req, res, next) {
  const key = req.headers['x-api-key'] || req.query.apiKey;
  if (!key || key !== process.env.API_KEY) {
    return res.status(401).json({
      success: false,
      error: 'Unauthorised – valid API key required (x-api-key header or ?apiKey= query param)',
    });
  }
  next();
}

/**
 * validate — builds an inline body-validation middleware from a rules map.
 *
 * rules shape:  { fieldName: { type, required, min, max, enum } }
 *
 * Example:
 *   validate({
 *     used:   { type: 'number', required: true, min: 0 },
 *     status: { type: 'string', enum: ['ok','warn','off'] },
 *   })
 */
function validate(rules) {
  return (req, res, next) => {
    const errors = [];

    for (const [field, rule] of Object.entries(rules)) {
      const value = req.body[field];
      const present = value !== undefined && value !== null && value !== '';

      if (rule.required && !present) {
        errors.push(`"${field}" is required`);
        continue; // skip further checks for this field
      }

      if (!present) continue; // optional field not supplied – fine

      if (rule.type === 'number') {
        const n = Number(value);
        if (isNaN(n)) {
          errors.push(`"${field}" must be a number`);
          continue;
        }
        if (rule.min !== undefined && n < rule.min)
          errors.push(`"${field}" must be ≥ ${rule.min}`);
        if (rule.max !== undefined && n > rule.max)
          errors.push(`"${field}" must be ≤ ${rule.max}`);
      }

      if (rule.type === 'string' && typeof value !== 'string') {
        errors.push(`"${field}" must be a string`);
        continue;
      }

      if (rule.enum && !rule.enum.includes(value)) {
        errors.push(`"${field}" must be one of: ${rule.enum.join(', ')}`);
      }
    }

    if (errors.length) {
      return res.status(400).json({ success: false, errors });
    }

    next();
  };
}

/**
 * notFound — 404 handler (mount after all routes)
 */
function notFound(req, res) {
  res.status(404).json({
    success: false,
    error: `Route ${req.method} ${req.originalUrl} not found`,
  });
}

/**
 * errorHandler — last-resort error handler
 */
function errorHandler(err, req, res, _next) {
  const status = err.status || err.statusCode || 500;
  console.error(`[error] ${req.method} ${req.originalUrl}`, err.message);
  res.status(status).json({
    success: false,
    error: process.env.NODE_ENV === 'production' ? 'Internal server error' : err.message,
  });
}

module.exports = { requireApiKey, validate, notFound, errorHandler };
