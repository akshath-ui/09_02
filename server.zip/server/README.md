# Smart Harbour API

Lightweight Express.js backend for the **Smart Fishing Harbour – Kerala 2026** project.  
Serves the static frontend, exposes REST endpoints for live fish prices, ice plant storage levels, and harbour announcements, and integrates cleanly with the existing `index.html` data model.

---

## Quick Start

```bash
cd smart-fishing-harbour/server
npm install
npm run dev        # nodemon hot-reload
# OR
npm start          # plain node
```

Open `http://localhost:3001` → frontend  
Open `http://localhost:3001/api` → API endpoint map

---

## Configuration

Copy `.env.example` to `.env` and adjust:

| Variable | Default | Description |
|---|---|---|
| `PORT` | `3001` | Port the server listens on |
| `NODE_ENV` | `development` | `development` / `production` / `test` |
| `API_KEY` | `smart-harbour-dev-key-2026` | Secret key for all write operations |
| `CORS_ORIGIN` | `*` | Allowed CORS origin (set to your domain in production) |

---

## Authentication

Read operations (`GET`) are public.  
Write operations (`POST`, `PUT`, `DELETE`) require the API key sent as:

```
x-api-key: smart-harbour-dev-key-2026
```

or as a query param:

```
?apiKey=smart-harbour-dev-key-2026
```

---

## Endpoints

### Health

| Method | Path | Description |
|---|---|---|
| `GET` | `/api/health` | Service health, uptime, version |

---

### Fish Prices — `/api/prices`

| Method | Path | Auth | Description |
|---|---|---|---|
| `GET` | `/api/prices` | — | List all fish prices |
| `GET` | `/api/prices/:id` | — | Single fish record |
| `PUT` | `/api/prices/:id` | 🔑 | Update price fields |
| `GET` | `/api/prices/:id/history` | — | Last N price snapshots |

#### Query params — `GET /api/prices`

| Param | Example | Description |
|---|---|---|
| `harbour` | `Cochin` | Filter by origin harbour |
| `trend` | `up` / `down` | Filter by price trend |
| `minDemand` | `75` | Minimum demand % |
| `maxPrice` | `200` | Maximum price (max field) |
| `search` | `prawn` | Text search on name / Malayalam |

#### Update body — `PUT /api/prices/:id`

```jsonc
{
  "min": 45,          // number ≥ 0
  "max": 72,          // number ≥ 0, must be ≥ min
  "trend": "up",      // "up" | "down" | "stable"
  "demand": 90,       // 0–100
  "qty": 380,         // number ≥ 0  (kg available)
  "arrivedMins": 20,  // minutes since arrival
  "origin": "Cochin"  // harbour name string
}
```

#### Example

```bash
# Get all rising-trend fish
curl http://localhost:3001/api/prices?trend=up

# Update sardine price
curl -X PUT http://localhost:3001/api/prices/sardine \
  -H "Content-Type: application/json" \
  -H "x-api-key: smart-harbour-dev-key-2026" \
  -d '{"min":48,"max":75,"trend":"up","demand":92}'

# Price history (last 5 snapshots)
curl http://localhost:3001/api/prices/prawn/history?limit=5
```

---

### Ice Plant & Cold Storage — `/api/storage`

| Method | Path | Auth | Description |
|---|---|---|---|
| `GET` | `/api/storage` | — | List all units |
| `GET` | `/api/storage/summary` | — | Aggregate stats per harbour |
| `GET` | `/api/storage/harbour/:harbour` | — | Units for a specific harbour |
| `GET` | `/api/storage/:id` | — | Single unit |
| `PUT` | `/api/storage/:id` | 🔑 | Update storage level / status |

#### Query params — `GET /api/storage`

| Param | Example | Description |
|---|---|---|
| `harbour` | `Munambam` | Filter by harbour |
| `type` | `ice-plant` / `cold-storage` | Filter by unit type |
| `status` | `ok` / `warn` / `off` | Filter by derived status |

#### Update body — `PUT /api/storage/:id`

```jsonc
{
  "used": 95,       // number 0–capacity (tons)
  "status": "warn", // "ok" | "warn" | "off"
  "temp": "−2°C",   // temperature string
  "rate": "₹3.50/kg"
}
```

#### Example

```bash
# Summary view across all harbours
curl http://localhost:3001/api/storage/summary

# Update Cochin ice plant usage
curl -X PUT http://localhost:3001/api/storage/cochin-ice \
  -H "Content-Type: application/json" \
  -H "x-api-key: smart-harbour-dev-key-2026" \
  -d '{"used": 310, "status": "warn"}'

# All storage at Munambam
curl http://localhost:3001/api/storage/harbour/Munambam
```

---

### Harbour Announcements — `/api/announcements`

| Method | Path | Auth | Description |
|---|---|---|---|
| `GET` | `/api/announcements` | — | List all (paginated) |
| `GET` | `/api/announcements/harbour/:harbour` | — | For a specific harbour |
| `GET` | `/api/announcements/:id` | — | Single announcement |
| `POST` | `/api/announcements` | 🔑 | Create new announcement |
| `PUT` | `/api/announcements/:id` | 🔑 | Edit announcement |
| `DELETE` | `/api/announcements/:id` | 🔑 | Remove announcement |

#### Query params — `GET /api/announcements`

| Param | Example | Description |
|---|---|---|
| `harbour` | `Cochin` | Filter by harbour |
| `type` | `urgent` / `info` / `warning` / `notice` | Filter by type |
| `page` | `1` | Page number (default 1) |
| `limit` | `10` | Items per page (max 100, default 20) |

#### Create body — `POST /api/announcements`

```jsonc
{
  "title":    "Storm Alert – Munambam",          // required
  "preview":  "Fishermen advised to stay ashore", // required
  "detail":   "IMD has issued a red alert...",    // required
  "harbour":  "Munambam",                         // required — one of valid harbours or "All"
  "type":     "urgent",                           // required — "info"|"urgent"|"warning"|"notice"
  "postedBy": "Harbour Authority"                 // required
}
```

#### Example

```bash
# Post a new urgent announcement
curl -X POST http://localhost:3001/api/announcements \
  -H "Content-Type: application/json" \
  -H "x-api-key: smart-harbour-dev-key-2026" \
  -d '{
    "title":    "Auction Cancelled – Beypore",
    "preview":  "Today'\''s auction postponed due to generator failure.",
    "detail":   "The morning auction at Beypore Harbour scheduled for 7:00 AM has been postponed. Rescheduled for 2:00 PM. Contact 0495-2411022.",
    "harbour":  "Beypore",
    "type":     "urgent",
    "postedBy": "Beypore Harbour Authority"
  }'

# Delete announcement #3
curl -X DELETE http://localhost:3001/api/announcements/3 \
  -H "x-api-key: smart-harbour-dev-key-2026"
```

---

## Project Structure

```
smart-fishing-harbour/
├── index.html              ← Frontend (served as static file)
└── server/
    ├── server.js           ← Entry point, middleware setup, route mounting
    ├── package.json
    ├── .env                ← Local environment variables (git-ignored)
    ├── .env.example        ← Template to share
    ├── data/
    │   └── store.js        ← In-memory seed data (mirrors frontend data model)
    ├── middleware/
    │   └── index.js        ← requireApiKey, validate, notFound, errorHandler
    └── routes/
        ├── prices.js       ← /api/prices
        ├── storage.js      ← /api/storage
        └── announcements.js← /api/announcements
```

---

## Response Shape

All responses follow a consistent envelope:

```jsonc
// Success
{ "success": true, "data": { ... } }

// List
{ "success": true, "count": 8, "data": [ ... ] }

// Error
{ "success": false, "error": "Descriptive message" }

// Validation error
{ "success": false, "errors": ["\"min\" must be a number", ...] }
```

---

## Notes

- **In-memory store** — data resets on server restart. Swap `data/store.js` for a database (e.g., SQLite with `better-sqlite3`, or MongoDB with `mongoose`) for persistence.
- **Price history** — the PUT `/prices/:id` route automatically snapshots the previous price before applying the update, keeping up to 50 historical records per fish in memory.
- **Auto-status derivation** — the storage enrichment layer auto-derives `ok`/`warn` from fill percentage unless the unit is explicitly marked `off`.
