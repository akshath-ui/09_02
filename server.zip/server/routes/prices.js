'use strict';

/**
 * /api/prices
 *
 * GET    /api/prices              – list all fish prices (filterable)
 * GET    /api/prices/:id          – single fish price record
 * PUT    /api/prices/:id          – update min/max/trend/demand/qty for a fish  [🔑]
 * GET    /api/prices/:id/history  – last-N price snapshots for a fish
 */

const { Router } = require('express');
const { requireApiKey, validate } = require('../middleware');
const { fishPrices } = require('../data/store');

const router = Router();

// ── In-memory price history (keyed by fish id, stores up to 50 snapshots each) ─
const priceHistory = {};
fishPrices.forEach((f) => {
  priceHistory[f.id] = [{ min: f.min, max: f.max, demand: f.demand, recordedAt: f.updatedAt }];
});

// ── Helpers ───────────────────────────────────────────────────────────────────
function derivedStatus(fish) {
  const pct = (fish.used / fish.capacity) * 100;
  if (pct >= 95) return 'warn';
  return 'ok';
}

/** Compute freshness label from arrivedMins */
function freshnessLabel(mins) {
  if (mins <= 30) return 'Very Fresh';
  if (mins <= 90) return 'Fresh';
  if (mins <= 180) return 'Moderate';
  return 'Older Stock';
}

// ── GET /api/prices ───────────────────────────────────────────────────────────
router.get('/', (req, res) => {
  const { harbour, trend, minDemand, maxPrice, search } = req.query;

  let results = fishPrices.map((f) => ({
    ...f,
    freshness: freshnessLabel(f.arrivedMins),
    wholesaleMin: Math.round(f.min * 0.88),
    wholesaleMax: Math.round(f.max * 0.88),
  }));

  // Filter by harbour/origin
  if (harbour) {
    const h = harbour.toLowerCase();
    results = results.filter((f) => f.origin.toLowerCase() === h);
  }
  // Filter by trend
  if (trend === 'up' || trend === 'down') {
    results = results.filter((f) => f.trend === trend);
  }
  // Filter by minimum demand %
  if (minDemand !== undefined) {
    const md = Number(minDemand);
    if (!isNaN(md)) results = results.filter((f) => f.demand >= md);
  }
  // Filter by max price (uses max price field)
  if (maxPrice !== undefined) {
    const mp = Number(maxPrice);
    if (!isNaN(mp)) results = results.filter((f) => f.max <= mp);
  }
  // Text search (name / Malayalam name)
  if (search) {
    const s = search.toLowerCase();
    results = results.filter(
      (f) => f.name.toLowerCase().includes(s) || f.ml.includes(search)
    );
  }

  res.json({
    success: true,
    count: results.length,
    updatedAt: new Date().toISOString(),
    data: results,
  });
});

// ── GET /api/prices/:id ───────────────────────────────────────────────────────
router.get('/:id', (req, res) => {
  const fish = fishPrices.find((f) => f.id === req.params.id.toLowerCase());
  if (!fish) return res.status(404).json({ success: false, error: `Fish "${req.params.id}" not found` });

  res.json({
    success: true,
    data: {
      ...fish,
      freshness: freshnessLabel(fish.arrivedMins),
      wholesaleMin: Math.round(fish.min * 0.88),
      wholesaleMax: Math.round(fish.max * 0.88),
    },
  });
});

// ── PUT /api/prices/:id ───────────────────────────────────────────────────────
const priceUpdateRules = {
  min:         { type: 'number', min: 0 },
  max:         { type: 'number', min: 0 },
  trend:       { type: 'string', enum: ['up', 'down', 'stable'] },
  demand:      { type: 'number', min: 0, max: 100 },
  qty:         { type: 'number', min: 0 },
  arrivedMins: { type: 'number', min: 0 },
  origin:      { type: 'string' },
};

router.put(
  '/:id',
  requireApiKey,
  validate(priceUpdateRules),
  (req, res) => {
    const fish = fishPrices.find((f) => f.id === req.params.id.toLowerCase());
    if (!fish) return res.status(404).json({ success: false, error: `Fish "${req.params.id}" not found` });

    // Snapshot current price before applying update
    priceHistory[fish.id] = priceHistory[fish.id] || [];
    priceHistory[fish.id].unshift({
      min: fish.min,
      max: fish.max,
      demand: fish.demand,
      recordedAt: fish.updatedAt,
    });
    // Keep at most 50 snapshots
    if (priceHistory[fish.id].length > 50) priceHistory[fish.id].length = 50;

    // Apply only allowed fields
    const allowed = ['min', 'max', 'trend', 'demand', 'qty', 'arrivedMins', 'origin'];
    for (const key of allowed) {
      if (req.body[key] !== undefined) {
        fish[key] = key === 'origin' ? req.body[key] : Number(req.body[key]);
      }
    }
    // String fields
    if (req.body.trend) fish.trend = req.body.trend;
    if (req.body.origin) fish.origin = req.body.origin;

    // Validate min <= max
    if (fish.min > fish.max) {
      return res.status(400).json({ success: false, error: '"min" must be ≤ "max"' });
    }

    fish.updatedAt = new Date().toISOString();

    res.json({
      success: true,
      message: `Price for "${fish.name}" updated`,
      data: fish,
    });
  }
);

// ── GET /api/prices/:id/history ───────────────────────────────────────────────
router.get('/:id/history', (req, res) => {
  const fish = fishPrices.find((f) => f.id === req.params.id.toLowerCase());
  if (!fish) return res.status(404).json({ success: false, error: `Fish "${req.params.id}" not found` });

  const limit = Math.min(Number(req.query.limit) || 10, 50);
  const history = (priceHistory[fish.id] || []).slice(0, limit);

  res.json({
    success: true,
    fish: fish.name,
    count: history.length,
    data: history,
  });
});

module.exports = router;
