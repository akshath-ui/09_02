'use strict';

/**
 * /api/storage
 *
 * GET    /api/storage              – list all storage units (filterable)
 * GET    /api/storage/:id          – single unit
 * PUT    /api/storage/:id          – update used/status/temp for a unit  [🔑]
 * GET    /api/storage/harbour/:h   – all units for a given harbour
 * GET    /api/storage/summary      – aggregate capacity stats per harbour
 */

const { Router } = require('express');
const { requireApiKey, validate } = require('../middleware');
const { storageUnits } = require('../data/store');

const router = Router();

// ── Helpers ───────────────────────────────────────────────────────────────────
function enrichUnit(unit) {
  const pct = Math.round((unit.used / unit.capacity) * 100);
  const free = unit.capacity - unit.used;
  let derivedStatus = unit.status;
  // Auto-derive status from fill level if not explicitly 'off'
  if (unit.status !== 'off') {
    if (pct >= 95) derivedStatus = 'warn';
    else if (pct < 95) derivedStatus = 'ok';
  }
  return {
    ...unit,
    used: unit.used,
    free,
    fillPercent: pct,
    derivedStatus,
  };
}

// ── GET /api/storage ──────────────────────────────────────────────────────────
router.get('/', (req, res) => {
  const { harbour, type, status } = req.query;

  let results = storageUnits.map(enrichUnit);

  if (harbour) {
    const h = harbour.toLowerCase();
    results = results.filter((u) => u.harbour.toLowerCase() === h);
  }
  if (type) {
    const t = type.toLowerCase();
    results = results.filter((u) => u.type.toLowerCase().replace(' ', '-') === t || u.type.toLowerCase() === t);
  }
  if (status) {
    results = results.filter((u) => u.derivedStatus === status || u.status === status);
  }

  res.json({
    success: true,
    count: results.length,
    data: results,
  });
});

// ── GET /api/storage/summary ──────────────────────────────────────────────────
// NOTE: must be declared before /:id so Express doesn't mistake "summary" for an id
router.get('/summary', (req, res) => {
  const harbours = [...new Set(storageUnits.map((u) => u.harbour))];

  const summary = harbours.map((harbour) => {
    const units = storageUnits.filter((u) => u.harbour === harbour);
    const ice   = units.filter((u) => u.type === 'Ice Plant');
    const cold  = units.filter((u) => u.type === 'Cold Storage');

    function agg(list) {
      if (!list.length) return null;
      const totalCap  = list.reduce((s, u) => s + u.capacity, 0);
      const totalUsed = list.reduce((s, u) => s + u.used, 0);
      return {
        units: list.length,
        capacityTons: totalCap,
        usedTons: totalUsed,
        freeTons: totalCap - totalUsed,
        fillPercent: Math.round((totalUsed / totalCap) * 100),
        hasOffline: list.some((u) => u.status === 'off'),
      };
    }

    return {
      harbour,
      icePlants: agg(ice),
      coldStorage: agg(cold),
    };
  });

  res.json({ success: true, data: summary });
});

// ── GET /api/storage/harbour/:harbour ─────────────────────────────────────────
router.get('/harbour/:harbour', (req, res) => {
  const h = req.params.harbour.toLowerCase();
  const units = storageUnits
    .filter((u) => u.harbour.toLowerCase() === h)
    .map(enrichUnit);

  if (!units.length) {
    return res.status(404).json({ success: false, error: `No storage units found for harbour "${req.params.harbour}"` });
  }

  res.json({ success: true, count: units.length, data: units });
});

// ── GET /api/storage/:id ──────────────────────────────────────────────────────
router.get('/:id', (req, res) => {
  const unit = storageUnits.find((u) => u.id === req.params.id);
  if (!unit) return res.status(404).json({ success: false, error: `Storage unit "${req.params.id}" not found` });

  res.json({ success: true, data: enrichUnit(unit) });
});

// ── PUT /api/storage/:id ──────────────────────────────────────────────────────
const storageUpdateRules = {
  used:   { type: 'number', min: 0 },
  status: { type: 'string', enum: ['ok', 'warn', 'off'] },
  temp:   { type: 'string' },
  rate:   { type: 'string' },
};

router.put(
  '/:id',
  requireApiKey,
  validate(storageUpdateRules),
  (req, res) => {
    const unit = storageUnits.find((u) => u.id === req.params.id);
    if (!unit) return res.status(404).json({ success: false, error: `Storage unit "${req.params.id}" not found` });

    // Validate that used does not exceed capacity
    const newUsed = req.body.used !== undefined ? Number(req.body.used) : unit.used;
    if (newUsed > unit.capacity) {
      return res.status(400).json({
        success: false,
        error: `"used" (${newUsed}) cannot exceed capacity (${unit.capacity})`,
      });
    }

    if (req.body.used   !== undefined) unit.used   = Number(req.body.used);
    if (req.body.status !== undefined) unit.status = req.body.status;
    if (req.body.temp   !== undefined) unit.temp   = req.body.temp;
    if (req.body.rate   !== undefined) unit.rate   = req.body.rate;

    unit.updatedAt = new Date().toISOString();

    res.json({
      success: true,
      message: `Storage unit "${unit.name}" updated`,
      data: enrichUnit(unit),
    });
  }
);

module.exports = router;
