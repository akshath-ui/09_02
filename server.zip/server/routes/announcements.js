'use strict';

/**
 * /api/announcements
 *
 * GET    /api/announcements                  – list all (filterable by harbour, type)
 * GET    /api/announcements/:id              – single announcement
 * POST   /api/announcements                  – create a new announcement  [🔑]
 * PUT    /api/announcements/:id              – edit an existing one        [🔑]
 * DELETE /api/announcements/:id              – remove an announcement      [🔑]
 * GET    /api/announcements/harbour/:harbour – announcements for a harbour
 */

const { Router } = require('express');
const { requireApiKey, validate } = require('../middleware');
const { announcements, getNextAnnouncementId } = require('../data/store');

const router = Router();

const VALID_TYPES    = ['info', 'urgent', 'warning', 'notice'];
const VALID_HARBOURS = ['Munambam', 'Cochin', 'Sakthikulangara', 'Beypore', 'Ponnani', 'All'];

// ── GET /api/announcements ────────────────────────────────────────────────────
router.get('/', (req, res) => {
  const { harbour, type, limit: lq, page: pq } = req.query;

  let results = [...announcements].sort(
    (a, b) => new Date(b.createdAt) - new Date(a.createdAt)
  );

  if (harbour) {
    const h = harbour.toLowerCase();
    results = results.filter(
      (a) => a.harbour.toLowerCase() === h || a.harbour === 'All'
    );
  }
  if (type && VALID_TYPES.includes(type)) {
    results = results.filter((a) => a.type === type);
  }

  // Pagination
  const limit = Math.min(Number(lq) || 20, 100);
  const page  = Math.max(Number(pq)  || 1,  1);
  const total = results.length;
  const start = (page - 1) * limit;
  results = results.slice(start, start + limit);

  res.json({
    success: true,
    total,
    page,
    limit,
    count: results.length,
    data: results,
  });
});

// ── GET /api/announcements/harbour/:harbour ───────────────────────────────────
// Must appear before /:id to avoid matching "harbour" as an id
router.get('/harbour/:harbour', (req, res) => {
  const h = req.params.harbour.toLowerCase();
  const results = announcements
    .filter((a) => a.harbour.toLowerCase() === h || a.harbour === 'All')
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  res.json({ success: true, harbour: req.params.harbour, count: results.length, data: results });
});

// ── GET /api/announcements/:id ────────────────────────────────────────────────
router.get('/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) return res.status(400).json({ success: false, error: 'id must be an integer' });

  const item = announcements.find((a) => a.id === id);
  if (!item) return res.status(404).json({ success: false, error: `Announcement #${id} not found` });

  res.json({ success: true, data: item });
});

// ── POST /api/announcements ───────────────────────────────────────────────────
const createRules = {
  title:    { type: 'string', required: true },
  preview:  { type: 'string', required: true },
  detail:   { type: 'string', required: true },
  harbour:  { type: 'string', required: true, enum: VALID_HARBOURS },
  type:     { type: 'string', required: true, enum: VALID_TYPES },
  postedBy: { type: 'string', required: true },
};

router.post('/', requireApiKey, validate(createRules), (req, res) => {
  const now = new Date().toISOString();
  const dateStr = new Date().toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });

  const item = {
    id:        getNextAnnouncementId(),
    title:     req.body.title.trim(),
    date:      dateStr,
    type:      req.body.type,
    harbour:   req.body.harbour,
    preview:   req.body.preview.trim(),
    detail:    req.body.detail.trim(),
    postedBy:  req.body.postedBy.trim(),
    createdAt: now,
    updatedAt: now,
  };

  // Urgent items go to the front; info items to the back
  if (item.type === 'urgent' || item.type === 'warning') {
    announcements.unshift(item);
  } else {
    announcements.push(item);
  }

  res.status(201).json({
    success: true,
    message: 'Announcement created',
    data: item,
  });
});

// ── PUT /api/announcements/:id ────────────────────────────────────────────────
const updateRules = {
  title:    { type: 'string' },
  preview:  { type: 'string' },
  detail:   { type: 'string' },
  harbour:  { type: 'string', enum: VALID_HARBOURS },
  type:     { type: 'string', enum: VALID_TYPES },
  postedBy: { type: 'string' },
};

router.put('/:id', requireApiKey, validate(updateRules), (req, res) => {
  const id   = parseInt(req.params.id, 10);
  if (isNaN(id)) return res.status(400).json({ success: false, error: 'id must be an integer' });

  const item = announcements.find((a) => a.id === id);
  if (!item) return res.status(404).json({ success: false, error: `Announcement #${id} not found` });

  const editable = ['title', 'preview', 'detail', 'harbour', 'type', 'postedBy'];
  for (const key of editable) {
    if (req.body[key] !== undefined) item[key] = req.body[key].toString().trim();
  }
  item.updatedAt = new Date().toISOString();

  res.json({
    success: true,
    message: `Announcement #${id} updated`,
    data: item,
  });
});

// ── DELETE /api/announcements/:id ─────────────────────────────────────────────
router.delete('/:id', requireApiKey, (req, res) => {
  const id  = parseInt(req.params.id, 10);
  if (isNaN(id)) return res.status(400).json({ success: false, error: 'id must be an integer' });

  const idx = announcements.findIndex((a) => a.id === id);
  if (idx === -1) return res.status(404).json({ success: false, error: `Announcement #${id} not found` });

  const [removed] = announcements.splice(idx, 1);
  res.json({
    success: true,
    message: `Announcement #${id} deleted`,
    data: removed,
  });
});

module.exports = router;
